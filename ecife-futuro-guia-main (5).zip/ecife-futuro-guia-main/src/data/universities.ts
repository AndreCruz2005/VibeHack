import { University, Course } from '@/types/university';

// Cursos mockados para as universidades
const commonCourses: Course[] = [
  {
    id: 'adm',
    name: 'Administração',
    area: 'Negócios',
    duration: 8,
    shift: ['manhã', 'noite'],
    monthlyFee: 580,
    description: 'Formação em gestão empresarial e empreendedorismo'
  },
  {
    id: 'eng-civil',
    name: 'Engenharia Civil',
    area: 'Engenharia e Tecnologia',
    duration: 10,
    shift: ['manhã', 'noite'],
    monthlyFee: 890,
    description: 'Projeto e construção de obras de infraestrutura'
  },
  {
    id: 'direito',
    name: 'Direito',
    area: 'Direito',
    duration: 10,
    shift: ['manhã', 'tarde', 'noite'],
    monthlyFee: 750,
    description: 'Formação jurídica completa e prática advocatícia'
  },
  {
    id: 'psicologia',
    name: 'Psicologia',
    area: 'Saúde',
    duration: 10,
    shift: ['manhã', 'noite'],
    monthlyFee: 820,
    description: 'Compreensão do comportamento e saúde mental'
  },
  {
    id: 'enfermagem',
    name: 'Enfermagem',
    area: 'Saúde',
    duration: 8,
    shift: ['manhã', 'tarde', 'noite'],
    monthlyFee: 650,
    description: 'Cuidados de saúde e assistência ao paciente'
  },
  {
    id: 'pedagogia',
    name: 'Pedagogia',
    area: 'Educação',
    duration: 8,
    shift: ['manhã', 'noite'],
    monthlyFee: 480,
    description: 'Formação de educadores e gestão escolar'
  },
  {
    id: 'sis-info',
    name: 'Sistemas de Informação',
    area: 'Engenharia e Tecnologia',
    duration: 8,
    shift: ['manhã', 'noite'],
    monthlyFee: 720,
    description: 'Desenvolvimento de sistemas e tecnologia'
  },
  {
    id: 'jornalismo',
    name: 'Jornalismo',
    area: 'Comunicação',
    duration: 8,
    shift: ['manhã', 'noite'],
    monthlyFee: 680,
    description: 'Comunicação, mídia e produção jornalística'
  }
];

export const universities: University[] = [
  {
    id: 'uninassau',
    name: 'Universidade Maurício de Nassau',
    shortName: 'UNINASSAU',
    location: {
      address: 'Av. Governador Agamenon Magalhães, 4200 - Derby',
      neighborhood: 'Derby',
      zone: 'Norte',
      coordinates: [-34.8866, -8.0531]
    },
    rating: {
      mec: 3.2,
      student: 4.1,
      infrastructure: 3.8
    },
    courses: commonCourses.filter(course => 
      ['adm', 'direito', 'enfermagem', 'pedagogia', 'sis-info'].includes(course.id)
    ),
    scholarships: {
      prouni: true,
      fies: true,
      internal: true,
      percentage: 70
    },
    costs: {
      averageMonthlyFee: 650,
      registrationFee: 150,
      additionalFees: ['Material didático', 'Laboratórios']
    },
    infrastructure: {
      library: true,
      labs: true,
      cafeteria: true,
      parking: true,
      accessibility: true,
      sports: false
    },
    transport: {
      busLines: ['001', '042', '075', '301'],
      metro: true,
      nearbyStops: ['Estação Derby', 'Terminal Derby']
    },
    contact: {
      phone: '(81) 3421-4000',
      email: 'recife@uninassau.edu.br',
      website: 'https://uninassau.edu.br'
    },
    highlights: [
      'Ampla oferta de bolsas',
      'Localização central',
      'Infraestrutura moderna',
      'Parcerias com empresas'
    ]
  },
  {
    id: 'fbv',
    name: 'Faculdade Boa Viagem',
    shortName: 'FBV',
    location: {
      address: 'Rua Jean Emile Favre, 422 - Imbiribeira',
      neighborhood: 'Imbiribeira',
      zone: 'Sul',
      coordinates: [-34.8943, -8.1189]
    },
    rating: {
      mec: 3.8,
      student: 4.3,
      infrastructure: 4.1
    },
    courses: commonCourses.filter(course => 
      ['adm', 'eng-civil', 'direito', 'psicologia', 'jornalismo'].includes(course.id)
    ),
    scholarships: {
      prouni: true,
      fies: true,
      internal: true,
      percentage: 65
    },
    costs: {
      averageMonthlyFee: 780,
      registrationFee: 200,
      additionalFees: ['Seguro estudantil', 'Material de apoio']
    },
    infrastructure: {
      library: true,
      labs: true,
      cafeteria: true,
      parking: true,
      accessibility: true,
      sports: true
    },
    transport: {
      busLines: ['052', '194', '542'],
      metro: false,
      nearbyStops: ['Imbiribeira Shopping', 'Aeroporto']
    },
    contact: {
      phone: '(81) 3463-7777',
      email: 'atendimento@fbv.edu.br',
      website: 'https://fbv.edu.br'
    },
    highlights: [
      'Excelente avaliação estudantil',
      'Campus moderno',
      'Clínicas de atendimento',
      'Programa de estágios'
    ]
  },
  {
    id: 'estacio',
    name: 'Universidade Estácio de Sá',
    shortName: 'Estácio',
    location: {
      address: 'Av. Eng. Abdias de Carvalho, 1678 - Madalena',
      neighborhood: 'Madalena',
      zone: 'Oeste',
      coordinates: [-34.9114, -8.0539]
    },
    rating: {
      mec: 3.0,
      student: 3.9,
      infrastructure: 3.5
    },
    courses: commonCourses.filter(course => 
      ['adm', 'direito', 'enfermagem', 'pedagogia', 'sis-info', 'eng-civil'].includes(course.id)
    ),
    scholarships: {
      prouni: true,
      fies: true,
      internal: true,
      percentage: 75
    },
    costs: {
      averageMonthlyFee: 590,
      registrationFee: 120,
      additionalFees: ['Taxa de renovação', 'Atividades complementares']
    },
    infrastructure: {
      library: true,
      labs: true,
      cafeteria: true,
      parking: false,
      accessibility: true,
      sports: false
    },
    transport: {
      busLines: ['028', '145', '260'],
      metro: false,
      nearbyStops: ['Shopping Madalena', 'Praça da Madalena']
    },
    contact: {
      phone: '(81) 3302-4500',
      email: 'recife@estacio.br',
      website: 'https://estacio.br'
    },
    highlights: [
      'Mensalidades acessíveis',
      'Ensino à distância',
      'Flexibilidade de horários',
      'Reconhecimento nacional'
    ]
  },
  {
    id: 'unicap',
    name: 'Universidade Católica de Pernambuco',
    shortName: 'UNICAP',
    location: {
      address: 'Rua do Príncipe, 526 - Boa Vista',
      neighborhood: 'Boa Vista',
      zone: 'Centro',
      coordinates: [-34.8776, -8.0486]
    },
    rating: {
      mec: 4.2,
      student: 4.5,
      infrastructure: 4.3
    },
    courses: commonCourses.filter(course => 
      ['adm', 'direito', 'psicologia', 'enfermagem', 'pedagogia', 'jornalismo'].includes(course.id)
    ),
    scholarships: {
      prouni: true,
      fies: true,
      internal: true,
      percentage: 55
    },
    costs: {
      averageMonthlyFee: 950,
      registrationFee: 300,
      additionalFees: ['Pastoral universitária', 'Eventos acadêmicos']
    },
    infrastructure: {
      library: true,
      labs: true,
      cafeteria: true,
      parking: true,
      accessibility: true,
      sports: true
    },
    transport: {
      busLines: ['010', '032', '045', '101'],
      metro: true,
      nearbyStops: ['Estação Central', 'Marco Zero']
    },
    contact: {
      phone: '(81) 2119-4000',
      email: 'vestibular@unicap.br',
      website: 'https://unicap.br'
    },
    highlights: [
      'Tradição e qualidade',
      'Reconhecimento nacional',
      'Extensão social',
      'Centro da cidade'
    ],
    warnings: [
      'Mensalidades mais altas',
      'Processo seletivo concorrido'
    ]
  },
  {
    id: 'devry',
    name: 'Centro Universitário DeVry',
    shortName: 'DeVry',
    location: {
      address: 'Av. Antônio de Goes, 60 - Pina',
      neighborhood: 'Pina',
      zone: 'Sul',
      coordinates: [-34.8756, -8.0856]
    },
    rating: {
      mec: 3.5,
      student: 4.0,
      infrastructure: 3.9
    },
    courses: commonCourses.filter(course => 
      ['adm', 'eng-civil', 'sis-info', 'jornalismo'].includes(course.id)
    ),
    scholarships: {
      prouni: true,
      fies: true,
      internal: true,
      percentage: 60
    },
    costs: {
      averageMonthlyFee: 820,
      registrationFee: 250,
      additionalFees: ['Tecnologia educacional', 'Certificações']
    },
    infrastructure: {
      library: true,
      labs: true,
      cafeteria: true,
      parking: true,
      accessibility: true,
      sports: false
    },
    transport: {
      busLines: ['015', '187', '388'],
      metro: false,
      nearbyStops: ['Shopping RioMar', 'Praia do Pina']
    },
    contact: {
      phone: '(81) 3047-7000',
      email: 'recife@devry.edu.br',
      website: 'https://devry.edu.br'
    },
    highlights: [
      'Foco em tecnologia',
      'Metodologia internacional',
      'Parcerias empresariais',
      'Infraestrutura digital'
    ]
  }
];

// Dados para cálculo de transporte
export const transportCosts = {
  busPerTrip: 4.50,
  metroBusCombo: 5.20,
  monthlyPass: 180,
  averageFoodPerDay: 15,
  monthlyMaterials: 80
};

// Áreas de curso para o quiz vocacional
export const courseAreas = [
  'Engenharia e Tecnologia',
  'Saúde',
  'Humanas', 
  'Negócios',
  'Educação',
  'Arte e Design',
  'Direito',
  'Comunicação'
] as const;