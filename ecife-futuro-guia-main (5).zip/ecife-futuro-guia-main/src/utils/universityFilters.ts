import { University, FilterOptions, CostCalculation, CourseArea } from '@/types/university';
import { transportCosts } from '@/data/universities';

export const filterUniversities = (
  universities: University[], 
  filters: FilterOptions,
  userLocation?: [number, number]
): University[] => {
  return universities.filter(university => {
    // Filtro de localização
    if (filters.location) {
      if (filters.location.neighborhood && 
          university.location.neighborhood !== filters.location.neighborhood) {
        return false;
      }
      
      if (filters.location.zone && 
          university.location.zone !== filters.location.zone) {
        return false;
      }

      if (filters.location.maxDistance && userLocation) {
        const distance = calculateDistance(
          userLocation, 
          university.location.coordinates
        );
        if (distance > filters.location.maxDistance) {
          return false;
        }
      }
    }

    // Filtro de orçamento
    if (filters.budget?.maxMonthlyFee) {
      if (university.costs.averageMonthlyFee > filters.budget.maxMonthlyFee) {
        return false;
      }
    }

    // Filtro de curso
    if (filters.course?.area) {
      const hasArea = university.courses.some(course => 
        course.area === filters.course?.area
      );
      if (!hasArea) {
        return false;
      }
    }

    // Filtro de bolsas
    if (filters.scholarships) {
      if (filters.scholarships.prouni && !university.scholarships.prouni) {
        return false;
      }
      if (filters.scholarships.fies && !university.scholarships.fies) {
        return false;
      }
      if (filters.scholarships.internal && !university.scholarships.internal) {
        return false;
      }
    }

    // Filtro de infraestrutura
    if (filters.infrastructure) {
      if (filters.infrastructure.accessibility && 
          !university.infrastructure.accessibility) {
        return false;
      }
      if (filters.infrastructure.parking && 
          !university.infrastructure.parking) {
        return false;
      }
      if (filters.infrastructure.cafeteria && 
          !university.infrastructure.cafeteria) {
        return false;
      }
    }

    return true;
  });
};

export const calculateDistance = (
  coord1: [number, number], 
  coord2: [number, number]
): number => {
  const R = 6371; // Earth's radius in km
  const dLat = (coord2[1] - coord1[1]) * Math.PI / 180;
  const dLon = (coord2[0] - coord1[0]) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(coord1[1] * Math.PI / 180) * Math.cos(coord2[1] * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

export const calculateTotalCost = (
  university: University,
  userLocation?: [number, number],
  includeTransport: boolean = true,
  includeFood: boolean = true
): CostCalculation => {
  const monthlyFee = university.costs.averageMonthlyFee;
  let transport = 0;
  let food = 0;
  const materials = transportCosts.monthlyMaterials;

  // Calcular transporte
  if (includeTransport) {
    if (university.transport.metro) {
      transport = transportCosts.monthlyPass;
    } else {
      // Assumir 2 viagens por dia útil (ida e volta) x 22 dias
      transport = transportCosts.busPerTrip * 2 * 22;
    }

    // Adicionar custo extra se for longe
    if (userLocation) {
      const distance = calculateDistance(userLocation, university.location.coordinates);
      if (distance > 20) {
        transport *= 1.3; // 30% adicional para distâncias maiores
      }
    }
  }

  // Calcular alimentação
  if (includeFood) {
    if (university.infrastructure.cafeteria) {
      food = transportCosts.averageFoodPerDay * 22; // 22 dias úteis
    } else {
      food = transportCosts.averageFoodPerDay * 1.5 * 22; // 50% mais caro sem refeitório
    }
  }

  const total = monthlyFee + transport + food + materials;

  return {
    monthlyFee,
    transport,
    food,
    materials,
    total,
    breakdown: [
      {
        label: 'Mensalidade',
        value: monthlyFee,
        description: 'Valor base da mensalidade'
      },
      {
        label: 'Transporte',
        value: transport,
        description: includeTransport 
          ? (university.transport.metro ? 'Passe mensal (metrô + ônibus)' : 'Ônibus (44 viagens/mês)')
          : 'Não incluído'
      },
      {
        label: 'Alimentação',
        value: food,
        description: includeFood
          ? (university.infrastructure.cafeteria 
              ? 'Refeições no campus (22 dias)' 
              : 'Refeições externas (22 dias)')
          : 'Não incluído'
      },
      {
        label: 'Materiais',
        value: materials,
        description: 'Livros, apostilas e materiais básicos'
      }
    ]
  };
};

export const sortUniversities = (
  universities: University[], 
  sortBy: 'price' | 'rating' | 'distance' | 'scholarships',
  userLocation?: [number, number]
): University[] => {
  return [...universities].sort((a, b) => {
    switch (sortBy) {
      case 'price':
        return a.costs.averageMonthlyFee - b.costs.averageMonthlyFee;
      
      case 'rating':
        const avgA = (a.rating.mec + a.rating.student + a.rating.infrastructure) / 3;
        const avgB = (b.rating.mec + b.rating.student + b.rating.infrastructure) / 3;
        return avgB - avgA;
      
      case 'distance':
        if (!userLocation) return 0;
        const distA = calculateDistance(userLocation, a.location.coordinates);
        const distB = calculateDistance(userLocation, b.location.coordinates);
        return distA - distB;
      
      case 'scholarships':
        return b.scholarships.percentage - a.scholarships.percentage;
      
      default:
        return 0;
    }
  });
};

export const getRecommendedUniversities = (
  universities: University[],
  preferredAreas: CourseArea[],
  maxBudget?: number,
  userLocation?: [number, number]
): University[] => {
  // Calcular pontuação para cada universidade
  const scored = universities.map(university => {
    let score = 0;

    // Pontos por área de curso (máximo: 30 pontos)
    preferredAreas.forEach(area => {
      const hasArea = university.courses.some(course => course.area === area);
      if (hasArea) score += 10;
    });

    // Pontos por avaliação (máximo: 25 pontos)
    const avgRating = (
      university.rating.mec + 
      university.rating.student + 
      university.rating.infrastructure
    ) / 3;
    score += avgRating * 5;

    // Pontos por orçamento (máximo: 20 pontos)
    if (maxBudget) {
      const costRatio = university.costs.averageMonthlyFee / maxBudget;
      if (costRatio <= 0.7) score += 20;
      else if (costRatio <= 0.85) score += 15;
      else if (costRatio <= 1) score += 10;
    }

    // Pontos por bolsas (máximo: 15 pontos)
    score += (university.scholarships.percentage / 100) * 15;

    // Pontos por acessibilidade (máximo: 10 pontos)
    if (university.infrastructure.accessibility) score += 10;

    return { university, score };
  });

  // Ordenar por pontuação e retornar as top 3
  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(item => item.university);
};