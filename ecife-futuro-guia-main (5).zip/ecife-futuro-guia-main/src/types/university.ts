export interface University {
  id: string;
  name: string;
  shortName: string;
  location: {
    address: string;
    neighborhood: string;
    zone: string;
    coordinates: [number, number]; // [longitude, latitude]
  };
  logo?: string;
  rating: {
    mec: number;
    student: number;
    infrastructure: number;
  };
  courses: Course[];
  scholarships: {
    prouni: boolean;
    fies: boolean;
    internal: boolean;
    percentage: number;
  };
  costs: {
    averageMonthlyFee: number;
    registrationFee: number;
    additionalFees: string[];
  };
  infrastructure: {
    library: boolean;
    labs: boolean;
    cafeteria: boolean;
    parking: boolean;
    accessibility: boolean;
    sports: boolean;
  };
  transport: {
    busLines: string[];
    metro: boolean;
    nearbyStops: string[];
  };
  contact: {
    phone: string;
    email: string;
    website: string;
  };
  highlights: string[];
  warnings?: string[];
}

export interface Course {
  id: string;
  name: string;
  area: CourseArea;
  duration: number; // semestres
  shift: ('manhã' | 'tarde' | 'noite')[];
  monthlyFee: number;
  description: string;
}

export type CourseArea = 
  | 'Engenharia e Tecnologia'
  | 'Saúde'
  | 'Humanas'
  | 'Negócios'
  | 'Educação'
  | 'Arte e Design'
  | 'Direito'
  | 'Comunicação';

export interface FilterOptions {
  location?: {
    neighborhood?: string;
    zone?: string;
    maxDistance?: number;
    userLocation?: [number, number];
  };
  budget?: {
    maxMonthlyFee?: number;
    includeTransport?: boolean;
    includeFood?: boolean;
  };
  course?: {
    area?: CourseArea;
    specific?: string;
  };
  scholarships?: {
    prouni?: boolean;
    fies?: boolean;
    internal?: boolean;
  };
  infrastructure?: {
    accessibility?: boolean;
    parking?: boolean;
    cafeteria?: boolean;
  };
}

export interface CostCalculation {
  monthlyFee: number;
  transport: number;
  food: number;
  materials: number;
  total: number;
  breakdown: {
    label: string;
    value: number;
    description: string;
  }[];
}