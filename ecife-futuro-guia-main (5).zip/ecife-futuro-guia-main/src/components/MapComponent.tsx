import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { University } from '@/types/university';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Navigation, 
  DollarSign, 
  Bus, 
  AlertCircle,
  Info
} from 'lucide-react';

interface MapComponentProps {
  universities: University[];
  onUniversitySelect: (university: University) => void;
  userLocation?: [number, number];
}

const MapComponent = ({ universities, onUniversitySelect, userLocation }: MapComponentProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [selectedUniversity, setSelectedUniversity] = useState<University | null>(null);
  const [mapboxToken, setMapboxToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);

  useEffect(() => {
    if (!mapboxToken || !mapContainer.current) return;

    // Initialize map
    mapboxgl.accessToken = mapboxToken;
    
    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/light-v11',
        center: [-34.8851, -8.0476], // Recife center
        zoom: 11,
        pitch: 0,
      });

      // Add navigation controls
      map.current.addControl(
        new mapboxgl.NavigationControl({
          visualizePitch: true,
        }),
        'top-right'
      );

      // Add user location if available
      if (userLocation) {
        new mapboxgl.Marker({
          color: '#22c55e', // green
          scale: 1.2
        })
          .setLngLat(userLocation)
          .setPopup(
            new mapboxgl.Popup().setHTML(`
              <div class="p-2">
                <h3 class="font-semibold text-green-600">Sua Localização</h3>
                <p class="text-sm">Ponto de referência para cálculos</p>
              </div>
            `)
          )
          .addTo(map.current);
      }

      // Add university markers
      universities.forEach((university) => {
        const marker = new mapboxgl.Marker({
          color: '#3b82f6', // blue
          scale: 0.8
        })
          .setLngLat(university.location.coordinates)
          .setPopup(
            new mapboxgl.Popup().setHTML(`
              <div class="p-3 max-w-xs">
                <h3 class="font-semibold text-blue-600 mb-2">${university.name}</h3>
                <p class="text-sm text-gray-600 mb-2">${university.location.address}</p>
                <div class="space-y-1 text-xs">
                  <div class="flex items-center justify-between">
                    <span>Mensalidade média:</span>
                    <span class="font-semibold">R$ ${university.costs.averageMonthlyFee}</span>
                  </div>
                  <div class="flex items-center justify-between">
                    <span>Avaliação MEC:</span>
                    <span class="font-semibold">${university.rating.mec}/5</span>
                  </div>
                  <div class="flex items-center justify-between">
                    <span>Cursos:</span>
                    <span class="font-semibold">${university.courses.length}</span>
                  </div>
                </div>
                <button 
                  onclick="window.selectUniversity('${university.id}')" 
                  class="mt-2 w-full bg-blue-600 text-white text-xs py-1 px-2 rounded hover:bg-blue-700"
                >
                  Ver Detalhes
                </button>
              </div>
            `)
          )
          .addTo(map.current);

        marker.getElement().addEventListener('click', () => {
          setSelectedUniversity(university);
        });
      });

      // Global function for popup buttons
      (window as any).selectUniversity = (id: string) => {
        const university = universities.find(u => u.id === id);
        if (university) {
          onUniversitySelect(university);
        }
      };

    } catch (error) {
      console.error('Erro ao inicializar o mapa:', error);
      setShowTokenInput(true);
    }

    // Cleanup
    return () => {
      map.current?.remove();
      delete (window as any).selectUniversity;
    };
  }, [mapboxToken, universities, userLocation, onUniversitySelect]);

  const handleTokenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mapboxToken.trim()) {
      setShowTokenInput(false);
    }
  };

  const calculateDistance = (coord1: [number, number], coord2: [number, number]) => {
    const R = 6371; // Earth's radius in km
    const dLat = (coord2[1] - coord1[1]) * Math.PI / 180;
    const dLon = (coord2[0] - coord1[0]) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(coord1[1] * Math.PI / 180) * Math.cos(coord2[1] * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  if (showTokenInput) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MapPin className="h-5 w-5 text-primary" />
            <span>Mapa Interativo</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
            <div className="flex items-start space-x-2">
              <Info className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-accent mb-2">
                  Token do Mapbox Necessário
                </h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Para visualizar o mapa interativo, você precisa inserir um token do Mapbox. 
                  Visite <a 
                    href="https://mapbox.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-accent hover:underline"
                  >
                    mapbox.com
                  </a> para obter seu token gratuito.
                </p>
                <form onSubmit={handleTokenSubmit} className="space-y-3">
                  <Input
                    type="text"
                    placeholder="Insira seu token do Mapbox"
                    value={mapboxToken}
                    onChange={(e) => setMapboxToken(e.target.value)}
                    className="focus-visible"
                  />
                  <Button type="submit" className="w-full focus-visible">
                    <MapPin className="h-4 w-4 mr-2" />
                    Carregar Mapa
                  </Button>
                </form>
              </div>
            </div>
          </div>
          
          {/* Lista simples das universidades enquanto o mapa não carrega */}
          <div className="space-y-3">
            <h4 className="font-semibold">Universidades Disponíveis:</h4>
            {universities.map((university) => (
              <div key={university.id} className="p-3 border rounded-lg space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h5 className="font-medium">{university.shortName}</h5>
                    <p className="text-sm text-muted-foreground">
                      {university.location.neighborhood} - Zona {university.location.zone}
                    </p>
                  </div>
                  <Badge variant="outline">
                    R$ {university.costs.averageMonthlyFee}
                  </Badge>
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => onUniversitySelect(university)}
                  className="w-full focus-visible"
                >
                  Ver Detalhes
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MapPin className="h-5 w-5 text-primary" />
          <span>Mapa das Universidades</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative w-full h-96 rounded-lg overflow-hidden">
            <div ref={mapContainer} className="absolute inset-0" />
          </div>
          
          {selectedUniversity && (
            <Card className="border-primary/20">
              <CardContent className="pt-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-semibold text-primary">
                      {selectedUniversity.name}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {selectedUniversity.location.address}
                    </p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-success" />
                    <span>R$ {selectedUniversity.costs.averageMonthlyFee}/mês</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Bus className="h-4 w-4 text-secondary" />
                    <span>{selectedUniversity.transport.busLines.length} linhas</span>
                  </div>
                </div>
                
                {userLocation && (
                  <div className="mt-3 p-2 bg-muted rounded">
                    <div className="flex items-center space-x-2">
                      <Navigation className="h-4 w-4 text-primary" />
                      <span className="text-sm">
                        Distância: {
                          calculateDistance(
                            userLocation, 
                            selectedUniversity.location.coordinates
                          ).toFixed(1)
                        } km
                      </span>
                    </div>
                  </div>
                )}
                
                <Button 
                  className="w-full mt-3 focus-visible"
                  onClick={() => onUniversitySelect(selectedUniversity)}
                >
                  Ver Detalhes Completos
                </Button>
              </CardContent>
            </Card>
          )}
          
          <div className="flex items-start space-x-2 text-xs text-muted-foreground">
            <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
            <p>
              Use os controles do mapa para navegar. Clique nos marcadores para ver informações das universidades.
              Os cálculos de distância são aproximados.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MapComponent;