import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, GraduationCap, Heart, Shield } from 'lucide-react';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: 'Início', href: '#home', icon: GraduationCap },
    { label: 'Universidades', href: '#universities', icon: Heart },
    { label: 'Quiz Vocacional', href: '#quiz', icon: GraduationCap },
    { label: 'Dicas de Segurança', href: '#security', icon: Shield }
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <GraduationCap className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-xl font-bold text-primary">Estima</h1>
            <p className="text-xs text-muted-foreground">Guia Universitário</p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="text-sm font-medium text-foreground hover:text-primary transition-colors focus-visible"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Mobile Navigation */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="outline" size="icon" className="focus-visible">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Abrir menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <div className="flex items-center space-x-2 mb-6">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold">Estima</span>
            </div>
            <nav className="flex flex-col space-y-4">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <a
                    key={item.label}
                    href={item.href}
                    onClick={() => setIsOpen(false)}
                    className="flex items-center space-x-3 text-sm font-medium text-foreground hover:text-primary transition-colors p-2 rounded-md hover:bg-muted focus-visible"
                  >
                    <Icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </a>
                );
              })}
            </nav>
            <div className="mt-8 p-4 bg-primary/10 rounded-lg">
              <h3 className="text-sm font-semibold text-primary mb-2">
                💡 Dica de Acessibilidade
              </h3>
              <p className="text-xs text-muted-foreground">
                Use as teclas Tab e Enter para navegar pelo site. Todas as funções estão acessíveis via teclado.
              </p>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
};

export default Header;