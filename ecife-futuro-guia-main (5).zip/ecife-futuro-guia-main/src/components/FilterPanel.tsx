import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { FilterOptions, CourseArea } from '@/types/university';
import { courseAreas } from '@/data/universities';
import { Filter, X, MapPin, DollarSign, GraduationCap, Award } from 'lucide-react';

interface FilterPanelProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  onClearFilters: () => void;
}

const FilterPanel = ({ filters, onFiltersChange, onClearFilters }: FilterPanelProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const updateFilter = (category: keyof FilterOptions, updates: any) => {
    onFiltersChange({
      ...filters,
      [category]: {
        ...filters[category],
        ...updates
      }
    });
  };

  const neighborhoods = [
    'Derby', 'Imbiribeira', 'Madalena', 'Boa Vista', 'Pina', 
    'Casa Amarela', 'Aflitos', 'Espinheiro', 'Graças', 'Torre'
  ];

  const zones = ['Norte', 'Sul', 'Centro', 'Oeste'];

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-primary" />
            <span>Filtros Inteligentes</span>
          </CardTitle>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onClearFilters}
              className="focus-visible"
            >
              <X className="h-4 w-4 mr-1" />
              Limpar
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsExpanded(!isExpanded)}
              className="md:hidden focus-visible"
            >
              {isExpanded ? 'Menos' : 'Mais'} filtros
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className={`space-y-6 ${!isExpanded ? 'hidden md:block' : ''}`}>
        {/* Localização */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <MapPin className="h-4 w-4 text-primary" />
            <Label className="text-sm font-medium">Localização</Label>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="neighborhood" className="text-xs text-muted-foreground">
                Bairro preferido
              </Label>
              <Select 
                value={filters.location?.neighborhood || ''} 
                onValueChange={(value) => 
                  updateFilter('location', { neighborhood: value || undefined })
                }
              >
                <SelectTrigger id="neighborhood" className="focus-visible">
                  <SelectValue placeholder="Qualquer bairro" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Qualquer bairro</SelectItem>
                  {neighborhoods.map(neighborhood => (
                    <SelectItem key={neighborhood} value={neighborhood}>
                      {neighborhood}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="zone" className="text-xs text-muted-foreground">
                Zona da cidade
              </Label>
              <Select 
                value={filters.location?.zone || ''} 
                onValueChange={(value) => 
                  updateFilter('location', { zone: value || undefined })
                }
              >
                <SelectTrigger id="zone" className="focus-visible">
                  <SelectValue placeholder="Qualquer zona" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Qualquer zona</SelectItem>
                  {zones.map(zone => (
                    <SelectItem key={zone} value={zone}>
                      Zona {zone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="distance" className="text-xs text-muted-foreground">
              Distância máxima: {filters.location?.maxDistance || 20} km
            </Label>
            <Slider
              id="distance"
              min={5}
              max={50}
              step={5}
              value={[filters.location?.maxDistance || 20]}
              onValueChange={(value) => 
                updateFilter('location', { maxDistance: value[0] })
              }
              className="mt-2"
            />
          </div>
        </div>

        {/* Orçamento */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <DollarSign className="h-4 w-4 text-success" />
            <Label className="text-sm font-medium">Orçamento</Label>
          </div>
          <div>
            <Label htmlFor="budget" className="text-xs text-muted-foreground">
              Máximo por mês (R$)
            </Label>
            <Input
              id="budget"
              type="number"
              placeholder="1000"
              value={filters.budget?.maxMonthlyFee || ''}
              onChange={(e) => 
                updateFilter('budget', { 
                  maxMonthlyFee: e.target.value ? parseInt(e.target.value) : undefined 
                })
              }
              className="focus-visible"
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="include-transport" 
                checked={filters.budget?.includeTransport || false}
                onCheckedChange={(checked) => 
                  updateFilter('budget', { includeTransport: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="include-transport" className="text-sm">
                Incluir custo de transporte
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="include-food" 
                checked={filters.budget?.includeFood || false}
                onCheckedChange={(checked) => 
                  updateFilter('budget', { includeFood: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="include-food" className="text-sm">
                Incluir custo de alimentação
              </Label>
            </div>
          </div>
        </div>

        {/* Curso */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <GraduationCap className="h-4 w-4 text-secondary" />
            <Label className="text-sm font-medium">Curso</Label>
          </div>
          <div>
            <Label htmlFor="course-area" className="text-xs text-muted-foreground">
              Área de interesse
            </Label>
            <Select 
              value={filters.course?.area || ''} 
              onValueChange={(value) => 
                updateFilter('course', { area: value as CourseArea || undefined })
              }
            >
              <SelectTrigger id="course-area" className="focus-visible">
                <SelectValue placeholder="Todas as áreas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Todas as áreas</SelectItem>
                {courseAreas.map(area => (
                  <SelectItem key={area} value={area}>
                    {area}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Bolsas */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Award className="h-4 w-4 text-accent" />
            <Label className="text-sm font-medium">Bolsas e Financiamentos</Label>
          </div>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="prouni" 
                checked={filters.scholarships?.prouni || false}
                onCheckedChange={(checked) => 
                  updateFilter('scholarships', { prouni: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="prouni" className="text-sm">ProUni</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="fies" 
                checked={filters.scholarships?.fies || false}
                onCheckedChange={(checked) => 
                  updateFilter('scholarships', { fies: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="fies" className="text-sm">FIES</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="internal" 
                checked={filters.scholarships?.internal || false}
                onCheckedChange={(checked) => 
                  updateFilter('scholarships', { internal: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="internal" className="text-sm">Bolsas da própria instituição</Label>
            </div>
          </div>
        </div>

        {/* Infraestrutura */}
        <div className="space-y-4">
          <Label className="text-sm font-medium">Infraestrutura Necessária</Label>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="accessibility" 
                checked={filters.infrastructure?.accessibility || false}
                onCheckedChange={(checked) => 
                  updateFilter('infrastructure', { accessibility: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="accessibility" className="text-sm">Acessibilidade</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="parking" 
                checked={filters.infrastructure?.parking || false}
                onCheckedChange={(checked) => 
                  updateFilter('infrastructure', { parking: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="parking" className="text-sm">Estacionamento</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="cafeteria" 
                checked={filters.infrastructure?.cafeteria || false}
                onCheckedChange={(checked) => 
                  updateFilter('infrastructure', { cafeteria: checked })
                }
                className="focus-visible"
              />
              <Label htmlFor="cafeteria" className="text-sm">Lanchonete/Refeitório</Label>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterPanel;