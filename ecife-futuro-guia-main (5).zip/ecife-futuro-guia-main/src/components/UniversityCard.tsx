import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { University } from '@/types/university';
import { 
  MapPin, 
  Star, 
  GraduationCap, 
  DollarSign, 
  Bus, 
  Accessibility,
  ChevronRight,
  Award,
  AlertTriangle
} from 'lucide-react';

interface UniversityCardProps {
  university: University;
  userLocation?: [number, number];
  onViewDetails: (id: string) => void;
  estimatedCost?: number;
}

const UniversityCard = ({ 
  university, 
  userLocation, 
  onViewDetails,
  estimatedCost 
}: UniversityCardProps) => {
  const averageRating = (
    (university.rating.mec + university.rating.student + university.rating.infrastructure) / 3
  ).toFixed(1);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 ${
          i < rating ? 'text-warning fill-warning' : 'text-muted-foreground'
        }`} 
      />
    ));
  };

  return (
    <Card className="w-full max-w-md mx-auto hover:shadow-lg transition-all duration-300 gradient-card border-0 focus-within:ring-2 focus-within:ring-primary">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-lg font-bold text-foreground line-clamp-2">
              {university.name}
            </h3>
            <p className="text-sm text-primary font-medium">
              {university.shortName}
            </p>
            <div className="flex items-center space-x-1 mt-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {university.location.neighborhood} - Zona {university.location.zone}
              </span>
            </div>
          </div>
          {university.scholarships.prouni && (
            <Badge variant="secondary" className="text-xs">
              <Award className="h-3 w-3 mr-1" />
              ProUni
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Avaliações */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1">
            {renderStars(Math.round(parseFloat(averageRating)))}
            <span className="text-sm font-medium ml-2">{averageRating}</span>
          </div>
          <span className="text-xs text-muted-foreground">
            MEC: {university.rating.mec}/5
          </span>
        </div>

        {/* Informações principais */}
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center space-x-2">
            <GraduationCap className="h-4 w-4 text-primary" />
            <span>{university.courses.length} cursos</span>
          </div>
          <div className="flex items-center space-x-2">
            <DollarSign className="h-4 w-4 text-success" />
            <span>R$ {university.costs.averageMonthlyFee}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Bus className="h-4 w-4 text-secondary" />
            <span>{university.transport.busLines.length} linhas</span>
          </div>
          {university.infrastructure.accessibility && (
            <div className="flex items-center space-x-2">
              <Accessibility className="h-4 w-4 text-accent" />
              <span>Acessível</span>
            </div>
          )}
        </div>

        {/* Bolsas disponíveis */}
        <div className="flex flex-wrap gap-1">
          {university.scholarships.prouni && (
            <Badge variant="outline" className="text-xs">ProUni</Badge>
          )}
          {university.scholarships.fies && (
            <Badge variant="outline" className="text-xs">FIES</Badge>
          )}
          {university.scholarships.internal && (
            <Badge variant="outline" className="text-xs">Bolsa Própria</Badge>
          )}
          <Badge variant="secondary" className="text-xs">
            {university.scholarships.percentage}% bolsas
          </Badge>
        </div>

        {/* Custo estimado */}
        {estimatedCost && (
          <div className="p-3 bg-success/10 rounded-lg border border-success/20">
            <p className="text-sm font-medium text-success">
              Custo total estimado: R$ {estimatedCost.toFixed(0)}/mês
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Inclui mensalidade, transporte e alimentação
            </p>
          </div>
        )}

        {/* Alertas */}
        {university.warnings && university.warnings.length > 0 && (
          <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="h-4 w-4 text-warning mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-warning">Atenção:</p>
                <ul className="text-xs text-muted-foreground mt-1">
                  {university.warnings.map((warning, index) => (
                    <li key={index}>• {warning}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter>
        <Button 
          onClick={() => onViewDetails(university.id)}
          className="w-full focus-visible"
          variant="default"
        >
          Ver Detalhes
          <ChevronRight className="h-4 w-4 ml-2" />
        </Button>
      </CardFooter>
    </Card>
  );
};

export default UniversityCard;