import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CourseArea } from '@/types/university';
import { 
  Brain, 
  ChevronLeft, 
  ChevronRight, 
  RotateCcw, 
  Lightbulb,
  Heart,
  Calculator,
  Wrench,
  Users,
  Palette,
  Scale,
  Megaphone
} from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: {
    text: string;
    areas: CourseArea[];
    icon: any;
  }[];
}

interface QuizVocacionalProps {
  onResult: (areas: CourseArea[]) => void;
  isOpen: boolean;
  onClose: () => void;
}

const questions: Question[] = [
  {
    id: 1,
    question: "O que mais te motiva no dia a dia?",
    options: [
      { text: "Resolver problemas complexos", areas: ['Engenharia e Tecnologia'], icon: Wrench },
      { text: "Ajudar outras pessoas", areas: ['Saúde', 'Educação'], icon: Heart },
      { text: "Trabalhar com números e dados", areas: ['Negócios'], icon: Calculator },
      { text: "Expressar criatividade", areas: ['Arte e Design', 'Comunicação'], icon: Palette },
      { text: "Debater e argumentar", areas: ['Direito'], icon: Scale },
      { text: "Entender comportamento humano", areas: ['Humanas'], icon: Brain }
    ]
  },
  {
    id: 2,
    question: "Em que ambiente você se sente mais produtivo?",
    options: [
      { text: "Laboratórios e oficinas", areas: ['Engenharia e Tecnologia'], icon: Wrench },
      { text: "Hospitais e clínicas", areas: ['Saúde'], icon: Heart },
      { text: "Escritórios e empresas", areas: ['Negócios'], icon: Calculator },
      { text: "Escolas e universidades", areas: ['Educação'], icon: Users },
      { text: "Estúdios e ateliês", areas: ['Arte e Design'], icon: Palette },
      { text: "Tribunais e escritórios jurídicos", areas: ['Direito'], icon: Scale }
    ]
  },
  {
    id: 3,
    question: "Que tipo de conteúdo você gosta de consumir?",
    options: [
      { text: "Documentários científicos", areas: ['Engenharia e Tecnologia', 'Saúde'], icon: Brain },
      { text: "Notícias e atualidades", areas: ['Comunicação', 'Humanas'], icon: Megaphone },
      { text: "Conteúdo de negócios", areas: ['Negócios'], icon: Calculator },
      { text: "Arte e cultura", areas: ['Arte e Design', 'Humanas'], icon: Palette },
      { text: "Programas educativos", areas: ['Educação'], icon: Users },
      { text: "Debates jurídicos", areas: ['Direito'], icon: Scale }
    ]
  },
  {
    id: 4,
    question: "Como você prefere trabalhar?",
    options: [
      { text: "Sozinho, focado em projetos", areas: ['Engenharia e Tecnologia'], icon: Wrench },
      { text: "Em equipe, ajudando pessoas", areas: ['Saúde', 'Educação'], icon: Heart },
      { text: "Liderando grupos", areas: ['Negócios'], icon: Calculator },
      { text: "De forma criativa e livre", areas: ['Arte e Design'], icon: Palette },
      { text: "Pesquisando e analisando", areas: ['Humanas'], icon: Brain },
      { text: "Representando interesses", areas: ['Direito'], icon: Scale }
    ]
  },
  {
    id: 5,
    question: "O que você considera mais importante no trabalho?",
    options: [
      { text: "Inovação e tecnologia", areas: ['Engenharia e Tecnologia'], icon: Wrench },
      { text: "Impacto social positivo", areas: ['Saúde', 'Educação'], icon: Heart },
      { text: "Sucesso financeiro", areas: ['Negócios'], icon: Calculator },
      { text: "Expressão pessoal", areas: ['Arte e Design', 'Comunicação'], icon: Palette },
      { text: "Conhecimento e pesquisa", areas: ['Humanas'], icon: Brain },
      { text: "Justiça e direitos", areas: ['Direito'], icon: Scale }
    ]
  }
];

const QuizVocacional = ({ onResult, isOpen, onClose }: QuizVocacionalProps) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<CourseArea[][]>([]);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (selectedAreas: CourseArea[]) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedAreas;
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResult(newAnswers);
    }
  };

  const calculateResult = (allAnswers: CourseArea[][]) => {
    const areaCount: { [key in CourseArea]: number } = {
      'Engenharia e Tecnologia': 0,
      'Saúde': 0,
      'Humanas': 0,
      'Negócios': 0,
      'Educação': 0,
      'Arte e Design': 0,
      'Direito': 0,
      'Comunicação': 0
    };

    allAnswers.forEach(answerAreas => {
      answerAreas.forEach(area => {
        areaCount[area]++;
      });
    });

    const sortedAreas = Object.entries(areaCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([area]) => area as CourseArea);

    setShowResult(true);
    onResult(sortedAreas);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
  };

  const goToPrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const getAreaIcon = (area: CourseArea) => {
    const iconMap = {
      'Engenharia e Tecnologia': Wrench,
      'Saúde': Heart,
      'Humanas': Brain,
      'Negócios': Calculator,
      'Educação': Users,
      'Arte e Design': Palette,
      'Direito': Scale,
      'Comunicação': Megaphone
    };
    return iconMap[area];
  };

  const getAreaDescription = (area: CourseArea) => {
    const descriptions = {
      'Engenharia e Tecnologia': 'Você tem perfil para resolver problemas técnicos e criar soluções inovadoras.',
      'Saúde': 'Você se identifica com cuidar de pessoas e promover bem-estar.',
      'Humanas': 'Você gosta de pesquisar, analisar e compreender a sociedade.',
      'Negócios': 'Você tem potencial para liderar, empreender e gerir recursos.',
      'Educação': 'Você tem vocação para ensinar e formar outras pessoas.',
      'Arte e Design': 'Você expressa criatividade e tem senso estético apurado.',
      'Direito': 'Você valoriza justiça e tem habilidade para argumentação.',
      'Comunicação': 'Você comunica bem e gosta de trabalhar com mídia e informação.'
    };
    return descriptions[area];
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-6 w-6 text-primary" />
            <span>Quiz Vocacional</span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onClose}
              className="ml-auto focus-visible"
            >
              Fechar
            </Button>
          </CardTitle>
          {!showResult && (
            <Progress 
              value={(currentQuestion + 1) / questions.length * 100} 
              className="mt-4"
            />
          )}
        </CardHeader>

        <CardContent>
          {!showResult ? (
            <div className="space-y-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">
                  Pergunta {currentQuestion + 1} de {questions.length}
                </p>
                <h3 className="text-xl font-semibold mt-2 text-accessible">
                  {questions[currentQuestion].question}
                </h3>
              </div>

              <div className="grid gap-3">
                {questions[currentQuestion].options.map((option, index) => {
                  const Icon = option.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      onClick={() => handleAnswer(option.areas)}
                      className="h-auto p-4 text-left justify-start hover:bg-primary/5 focus-visible"
                    >
                      <Icon className="h-5 w-5 mr-3 text-primary flex-shrink-0" />
                      <span className="text-accessible">{option.text}</span>
                    </Button>
                  );
                })}
              </div>

              <div className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={goToPrevious}
                  disabled={currentQuestion === 0}
                  className="focus-visible"
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Anterior
                </Button>
                <Button 
                  variant="outline" 
                  onClick={resetQuiz}
                  className="focus-visible"
                >
                  <RotateCcw className="h-4 w-4 mr-1" />
                  Recomeçar
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6 text-center">
              <div className="flex items-center justify-center space-x-2">
                <Lightbulb className="h-8 w-8 text-accent" />
                <h3 className="text-2xl font-bold">Suas Áreas Recomendadas!</h3>
              </div>

              <p className="text-muted-foreground text-accessible">
                Com base nas suas respostas, estas são as áreas que mais combinam com o seu perfil:
              </p>

              <div className="space-y-4">
                {answers.length > 0 && (() => {
                  const areaCount: { [key in CourseArea]: number } = {
                    'Engenharia e Tecnologia': 0,
                    'Saúde': 0,
                    'Humanas': 0,
                    'Negócios': 0,
                    'Educação': 0,
                    'Arte e Design': 0,
                    'Direito': 0,
                    'Comunicação': 0
                  };

                  answers.forEach(answerAreas => {
                    answerAreas.forEach(area => {
                      areaCount[area]++;
                    });
                  });

                  const sortedAreas = Object.entries(areaCount)
                    .sort(([,a], [,b]) => b - a)
                    .slice(0, 3)
                    .filter(([,count]) => count > 0);

                  return sortedAreas.map(([area, count], index) => {
                    const areaKey = area as CourseArea;
                    const Icon = getAreaIcon(areaKey);
                    return (
                      <div key={area} className="p-4 border rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`p-2 rounded-full ${
                              index === 0 ? 'bg-primary text-primary-foreground' :
                              index === 1 ? 'bg-secondary text-secondary-foreground' :
                              'bg-muted text-muted-foreground'
                            }`}>
                              <Icon className="h-5 w-5" />
                            </div>
                            <h4 className="text-lg font-semibold">{area}</h4>
                          </div>
                          <Badge variant={index === 0 ? 'default' : 'outline'}>
                            {index + 1}º lugar
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground text-left">
                          {getAreaDescription(areaKey)}
                        </p>
                      </div>
                    );
                  });
                })()}
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={resetQuiz} variant="outline" className="focus-visible">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Fazer Novamente
                </Button>
                <Button onClick={onClose} className="focus-visible">
                  <ChevronRight className="h-4 w-4 mr-2" />
                  Ver Universidades
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default QuizVocacional;