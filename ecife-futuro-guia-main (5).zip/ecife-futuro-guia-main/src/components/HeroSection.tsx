import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, MapPin, Heart, Star } from 'lucide-react';
import heroImage from '@/assets/hero-education.jpg';

interface HeroSectionProps {
  onGetStarted: () => void;
  onOpenQuiz: () => void;
}

const HeroSection = ({ onGetStarted, onOpenQuiz }: HeroSectionProps) => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-secondary/70 to-accent/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Badge */}
          <Badge variant="secondary" className="mx-auto bg-white/20 text-white border-white/30">
            <Heart className="h-4 w-4 mr-2" />
            Feito com amor para a periferia de Recife
          </Badge>

          {/* Main Heading */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
              Descubra sua
              <span className="block gradient-text bg-gradient-to-r from-accent to-warning bg-clip-text text-transparent">
                Universidade Ideal
              </span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed text-accessible">
              O <strong>Estima</strong> é seu guia inteligente para encontrar a melhor universidade privada 
              em Recife. Consideramos sua localização, orçamento e sonhos para te ajudar a escolher certo.
            </p>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-6 md:gap-8 text-white">
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-6 w-6 text-accent" />
              <div>
                <span className="text-2xl font-bold">5+</span>
                <p className="text-sm text-white/80">Universidades</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-6 w-6 text-accent" />
              <div>
                <span className="text-2xl font-bold">20+</span>
                <p className="text-sm text-white/80">Cursos</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Star className="h-6 w-6 text-accent" />
              <div>
                <span className="text-2xl font-bold">100%</span>
                <p className="text-sm text-white/80">Gratuito</p>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              onClick={onGetStarted}
              className="bg-white text-primary hover:bg-white/90 text-lg px-8 py-3 focus-visible smooth-bounce"
            >
              <GraduationCap className="h-5 w-5 mr-2" />
              Encontrar Universidade
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={onOpenQuiz}
              className="border-white text-white hover:bg-white/10 hover:text-white text-lg px-8 py-3 focus-visible"
            >
              <Heart className="h-5 w-5 mr-2" />
              Quiz Vocacional
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="pt-8 space-y-4">
            <p className="text-white/80 text-sm">
              ✅ Informações atualizadas • ✅ Cálculo de custos reais • ✅ Dicas contra fraudes
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Badge variant="outline" className="border-white/30 text-white text-xs">
                ProUni
              </Badge>
              <Badge variant="outline" className="border-white/30 text-white text-xs">
                FIES
              </Badge>
              <Badge variant="outline" className="border-white/30 text-white text-xs">
                Bolsas Próprias
              </Badge>
              <Badge variant="outline" className="border-white/30 text-white text-xs">
                Avaliação MEC
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-bounce" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;