import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, X } from 'lucide-react';

interface FloatingQuizButtonProps {
  onClick: () => void;
}

const FloatingQuizButton = ({ onClick }: FloatingQuizButtonProps) => {
  const [isMinimized, setIsMinimized] = useState(false);

  if (isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-40">
        <Button
          onClick={() => setIsMinimized(false)}
          className="rounded-full w-14 h-14 shadow-lg hover:shadow-xl transition-all focus-visible smooth-bounce"
          size="icon"
        >
          <Brain className="h-6 w-6" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-40 max-w-xs">
      <div className="bg-card border border-border rounded-lg shadow-xl p-4 space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-primary/10 rounded-full">
              <Brain className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold text-sm">Quiz Vocacional</h4>
              <Badge variant="secondary" className="text-xs">
                Gratuito
              </Badge>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 hover:bg-muted"
            onClick={() => setIsMinimized(true)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <p className="text-xs text-muted-foreground">
          Não sabe que curso escolher? Faça nosso quiz rápido e descubra áreas que combinam com você!
        </p>
        
        <Button 
          onClick={onClick}
          className="w-full text-xs focus-visible"
          size="sm"
        >
          <Brain className="h-4 w-4 mr-2" />
          Fazer Quiz
        </Button>
        
        <div className="text-center">
          <span className="text-xs text-muted-foreground">
            ⏱️ Apenas 2 minutos
          </span>
        </div>
      </div>
    </div>
  );
};

export default FloatingQuizButton;