import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Phone, 
  Eye,
  Lock,
  CreditCard,
  FileText,
  UserCheck
} from 'lucide-react';

const SecurityTips = () => {
  const fraudTypes = [
    {
      title: "Falsas Bolsas de Estudo",
      warning: "Golpistas oferecem bolsas 100% garantidas em troca de taxas antecipadas",
      icon: CreditCard,
      redFlags: [
        "Pedido de dinheiro antecipado",
        "Garantia de 100% de aprovação",
        "Pressão para decidir rapidamente",
        "Contato apenas por WhatsApp"
      ],
      protection: [
        "Consulte diretamente a universidade",
        "Verifique no site oficial do ProUni/FIES",
        "Nunca pague taxas antecipadas",
        "Desconfie de garantias irreais"
      ]
    },
    {
      title: "Universidades Fantasma",
      warning: "Instituições que não existem ou não são reconhecidas pelo MEC",
      icon: FileText,
      redFlags: [
        "Diploma em tempo muito curto",
        "Valores muito abaixo do mercado",
        "Site com pouca informação",
        "Não aparece no e-MEC"
      ],
      protection: [
        "Consulte o site oficial do e-MEC",
        "Visite o campus pessoalmente",
        "Procure ex-alunos nas redes sociais",
        "Verifique a nota do curso no MEC"
      ]
    },
    {
      title: "Documentos Falsos",
      warning: "Pedidos de documentos pessoais para supostas matrículas ou processos seletivos",
      icon: UserCheck,
      redFlags: [
        "Solicitação de documentos antes da matrícula",
        "Pedido de senhas bancárias",
        "Coleta de dados por telefone",
        "Urgência para envio de documentos"
      ],
      protection: [
        "Entregue documentos apenas presencialmente",
        "Nunca forneça senhas ou dados bancários",
        "Confirme processos nos canais oficiais",
        "Mantenha cópias de todos os documentos"
      ]
    }
  ];

  const verificationSteps = [
    {
      step: "Verificar no e-MEC",
      description: "Confirme se a universidade e o curso são reconhecidos",
      icon: CheckCircle,
      link: "https://emec.mec.gov.br/"
    },
    {
      step: "Visitar o Campus",
      description: "Conheça as instalações pessoalmente antes de se matricular",
      icon: Eye
    },
    {
      step: "Conferir Documentação",
      description: "Solicite e analise todos os documentos oficiais da instituição",
      icon: FileText
    },
    {
      step: "Pesquisar Avaliações",
      description: "Busque opiniões de alunos atuais e ex-alunos",
      icon: UserCheck
    }
  ];

  const emergencyContacts = [
    {
      name: "Procon Recife",
      phone: "151",
      description: "Problemas com contratos e serviços educacionais"
    },
    {
      name: "MEC - Ouvidoria",
      phone: "0800 616161",
      description: "Denúncias sobre instituições de ensino"
    },
    {
      name: "Polícia Civil - DECON",
      phone: "(81) 3184-3050",
      description: "Crimes contra o consumidor e estelionato"
    }
  ];

  return (
    <section id="security" className="space-y-8">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <Shield className="h-8 w-8 text-primary" />
          <h2 className="text-3xl font-bold">Dicas de Segurança</h2>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-accessible">
          Proteja-se de golpes comuns relacionados a universidades e bolsas de estudo. 
          Sua educação é importante demais para ser prejudicada por criminosos.
        </p>
      </div>

      {/* Alerta principal */}
      <Alert className="border-warning bg-warning/5">
        <AlertTriangle className="h-5 w-5 text-warning" />
        <AlertDescription className="text-accessible">
          <strong>⚠️ Atenção:</strong> Nunca pague taxas antecipadas para "garantir" bolsas de estudo. 
          As universidades legítimas só cobram após a matrícula confirmada.
        </AlertDescription>
      </Alert>

      {/* Tipos de golpes */}
      <div className="grid gap-6">
        <h3 className="text-2xl font-semibold text-center">Principais Golpes e Como Evitá-los</h3>
        
        {fraudTypes.map((fraud, index) => {
          const Icon = fraud.icon;
          return (
            <Card key={index} className="border-l-4 border-l-destructive">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <div className="p-2 bg-destructive/10 rounded-full">
                    <Icon className="h-5 w-5 text-destructive" />
                  </div>
                  <div>
                    <span className="text-destructive">{fraud.title}</span>
                    <p className="text-sm font-normal text-muted-foreground">
                      {fraud.warning}
                    </p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-destructive mb-3 flex items-center">
                      <XCircle className="h-4 w-4 mr-2" />
                      Sinais de Alerta
                    </h4>
                    <ul className="space-y-2">
                      {fraud.redFlags.map((flag, i) => (
                        <li key={i} className="flex items-start space-x-2 text-sm">
                          <span className="text-destructive font-bold mt-1">•</span>
                          <span>{flag}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-success mb-3 flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Como se Proteger
                    </h4>
                    <ul className="space-y-2">
                      {fraud.protection.map((tip, i) => (
                        <li key={i} className="flex items-start space-x-2 text-sm">
                          <span className="text-success font-bold mt-1">•</span>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Passos de verificação */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lock className="h-5 w-5 text-primary" />
            <span>Checklist de Verificação</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {verificationSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">{step.step}</h4>
                    <p className="text-xs text-muted-foreground">{step.description}</p>
                    {step.link && (
                      <a 
                        href={step.link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-xs text-primary hover:underline focus-visible"
                      >
                        Acessar site oficial
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Contatos de emergência */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Phone className="h-5 w-5 text-accent" />
            <span>Contatos para Denúncias</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {emergencyContacts.map((contact, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-semibold">{contact.name}</h4>
                  <p className="text-sm text-muted-foreground">{contact.description}</p>
                </div>
                <Badge variant="outline" className="font-mono">
                  {contact.phone}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Dicas extras */}
      <Card className="bg-success/5 border-success/20">
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <CheckCircle className="h-12 w-12 text-success mx-auto" />
            <h3 className="text-xl font-semibold text-success">Lembre-se:</h3>
            <div className="space-y-2 text-sm text-accessible">
              <p>✅ <strong>Educação de qualidade é um direito</strong>, não um privilégio</p>
              <p>✅ <strong>Sempre desconfie</strong> de ofertas que parecem boas demais</p>
              <p>✅ <strong>Pesquise bem</strong> antes de tomar qualquer decisão</p>
              <p>✅ <strong>Compartilhe</strong> essas dicas com família e amigos</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
};

export default SecurityTips;