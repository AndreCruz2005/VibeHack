import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

// Components
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import FilterPanel from '@/components/FilterPanel';
import UniversityCard from '@/components/UniversityCard';
import MapComponent from '@/components/MapComponent';
import QuizVocacional from '@/components/QuizVocacional';
import SecurityTips from '@/components/SecurityTips';
import FloatingQuizButton from '@/components/FloatingQuizButton';

// Data and utils
import { universities, transportCosts } from '@/data/universities';
import { filterUniversities, sortUniversities, calculateTotalCost, getRecommendedUniversities } from '@/utils/universityFilters';
import { University, FilterOptions, CourseArea } from '@/types/university';

// Icons
import { 
  Search, 
  SlidersHorizontal, 
  MapPin, 
  Star, 
  DollarSign,
  TrendingUp,
  Users,
  Award,
  ChevronDown,
  ChevronUp,
  Loader2,
  Target
} from 'lucide-react';

const Index = () => {
  // State management
  const [filters, setFilters] = useState<FilterOptions>({});
  const [sortBy, setSortBy] = useState<'price' | 'rating' | 'distance' | 'scholarships'>('rating');
  const [userLocation, setUserLocation] = useState<[number, number] | undefined>();
  const [showQuiz, setShowQuiz] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedUniversity, setSelectedUniversity] = useState<University | null>(null);
  const [quizResults, setQuizResults] = useState<CourseArea[]>([]);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  // Filtered and sorted universities
  const filteredUniversities = filterUniversities(universities, filters, userLocation);
  const sortedUniversities = sortUniversities(filteredUniversities, sortBy, userLocation);

  // Get user location
  const getUserLocation = () => {
    setIsLoadingLocation(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation([position.coords.longitude, position.coords.latitude]);
          toast.success('Localização obtida! Agora você pode ver distâncias precisas.');
          setIsLoadingLocation(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          toast.error('Não foi possível obter sua localização. Usando Recife como referência.');
          setUserLocation([-34.8851, -8.0476]); // Recife center
          setIsLoadingLocation(false);
        }
      );
    } else {
      toast.error('Geolocalização não suportada. Usando Recife como referência.');
      setUserLocation([-34.8851, -8.0476]);
      setIsLoadingLocation(false);
    }
  };

  // Handle quiz results
  const handleQuizResult = (areas: CourseArea[]) => {
    setQuizResults(areas);
    if (areas.length > 0) {
      setFilters(prev => ({
        ...prev,
        course: { area: areas[0] }
      }));
      toast.success(`Filtros atualizados com base no quiz: ${areas[0]}`);
    }
    setShowQuiz(false);
  };

  // Scroll to universities section
  const scrollToUniversities = () => {
    document.getElementById('universities')?.scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    });
  };

  // Calculate costs for filtered universities
  const universitiesWithCosts = sortedUniversities.map(university => ({
    university,
    estimatedCost: calculateTotalCost(
      university, 
      userLocation, 
      filters.budget?.includeTransport,
      filters.budget?.includeFood
    ).total
  }));

  // Get recommendations based on quiz
  const recommendations = quizResults.length > 0 
    ? getRecommendedUniversities(universities, quizResults, filters.budget?.maxMonthlyFee, userLocation)
    : [];

  // Stats for display
  const stats = {
    totalUniversities: universities.length,
    filteredCount: filteredUniversities.length,
    averagePrice: Math.round(
      filteredUniversities.reduce((sum, u) => sum + u.costs.averageMonthlyFee, 0) / 
      (filteredUniversities.length || 1)
    ),
    withScholarships: filteredUniversities.filter(u => 
      u.scholarships.prouni || u.scholarships.fies || u.scholarships.internal
    ).length
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <HeroSection 
        onGetStarted={scrollToUniversities}
        onOpenQuiz={() => setShowQuiz(true)}
      />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 space-y-12">
        
        {/* Recommendations from Quiz */}
        {recommendations.length > 0 && (
          <section className="space-y-6">
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-6 w-6 text-primary" />
                  <span>Recomendações Personalizadas</span>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Com base no seu perfil vocacional, estas universidades são ideais para você:
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  {recommendations.map((university) => (
                    <UniversityCard
                      key={university.id}
                      university={university}
                      userLocation={userLocation}
                      onViewDetails={(id) => {
                        const uni = universities.find(u => u.id === id);
                        if (uni) setSelectedUniversity(uni);
                      }}
                      estimatedCost={calculateTotalCost(
                        university, 
                        userLocation, 
                        filters.budget?.includeTransport,
                        filters.budget?.includeFood
                      ).total}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Universities Section */}
        <section id="universities" className="space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold">Universidades Disponíveis</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore nossa base completa de universidades privadas em Recife
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center space-x-2">
                  <Users className="h-5 w-5 text-primary" />
                  <span className="text-2xl font-bold">{stats.filteredCount}</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {stats.filteredCount === stats.totalUniversities ? 'Universidades' : 'Filtradas'}
                </p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center space-x-2">
                  <DollarSign className="h-5 w-5 text-success" />
                  <span className="text-2xl font-bold">R$ {stats.averagePrice}</span>
                </div>
                <p className="text-sm text-muted-foreground">Preço médio</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center space-x-2">
                  <Award className="h-5 w-5 text-accent" />
                  <span className="text-2xl font-bold">{stats.withScholarships}</span>
                </div>
                <p className="text-sm text-muted-foreground">Com bolsas</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={getUserLocation}
                  disabled={isLoadingLocation}
                  className="focus-visible"
                >
                  {isLoadingLocation ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <MapPin className="h-4 w-4" />
                  )}
                  <span className="ml-2">
                    {userLocation ? 'Atualizar' : 'Minha Localização'}
                  </span>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="flex flex-col lg:flex-row gap-4 items-start">
            <div className="flex-1 space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="focus-visible"
                >
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  Filtros
                  {showFilters ? 
                    <ChevronUp className="h-4 w-4 ml-2" /> : 
                    <ChevronDown className="h-4 w-4 ml-2" />
                  }
                </Button>
                
                <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                  <SelectTrigger className="w-full sm:w-48 focus-visible">
                    <SelectValue placeholder="Ordenar por..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rating">Melhor avaliação</SelectItem>
                    <SelectItem value="price">Menor preço</SelectItem>
                    <SelectItem value="scholarships">Mais bolsas</SelectItem>
                    {userLocation && (
                      <SelectItem value="distance">Mais próximo</SelectItem>
                    )}
                  </SelectContent>
                </Select>
                
                {Object.keys(filters).length > 0 && (
                  <Button
                    variant="outline"
                    onClick={() => setFilters({})}
                    className="focus-visible"
                  >
                    Limpar Filtros
                  </Button>
                )}
              </div>

              {/* Filters Panel */}
              {showFilters && (
                <FilterPanel
                  filters={filters}
                  onFiltersChange={setFilters}
                  onClearFilters={() => setFilters({})}
                />
              )}
            </div>
          </div>

          {/* Results */}
          {filteredUniversities.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Nenhuma universidade encontrada</h3>
                <p className="text-muted-foreground mb-4">
                  Tente ajustar seus filtros para ver mais opções
                </p>
                <Button onClick={() => setFilters({})} variant="outline">
                  Remover Filtros
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {universitiesWithCosts.map(({ university, estimatedCost }) => (
                <UniversityCard
                  key={university.id}
                  university={university}
                  userLocation={userLocation}
                  onViewDetails={(id) => {
                    const uni = universities.find(u => u.id === id);
                    if (uni) setSelectedUniversity(uni);
                  }}
                  estimatedCost={estimatedCost}
                />
              ))}
            </div>
          )}
        </section>

        {/* Map Section */}
        <section className="space-y-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Mapa Interativo</h2>
            <p className="text-lg text-muted-foreground">
              Visualize as universidades no mapa e calcule distâncias
            </p>
          </div>
          <MapComponent
            universities={filteredUniversities}
            onUniversitySelect={setSelectedUniversity}
            userLocation={userLocation}
          />
        </section>

        {/* Security Tips */}
        <SecurityTips />
      </main>

      {/* Floating Quiz Button */}
      <FloatingQuizButton onClick={() => setShowQuiz(true)} />

      {/* Quiz Modal */}
      <QuizVocacional
        isOpen={showQuiz}
        onClose={() => setShowQuiz(false)}
        onResult={handleQuizResult}
      />

      {/* University Details Modal */}
      {selectedUniversity && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 space-y-6">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-bold">{selectedUniversity.name}</h2>
                  <p className="text-muted-foreground">{selectedUniversity.location.address}</p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setSelectedUniversity(null)}
                  className="focus-visible"
                >
                  Fechar
                </Button>
              </div>

              {/* University details content would go here */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Informações Gerais</h3>
                  <div className="space-y-2 text-sm">
                    <p><strong>Localização:</strong> {selectedUniversity.location.neighborhood} - Zona {selectedUniversity.location.zone}</p>
                    <p><strong>Mensalidade média:</strong> R$ {selectedUniversity.costs.averageMonthlyFee}</p>
                    <p><strong>Avaliação MEC:</strong> {selectedUniversity.rating.mec}/5</p>
                    <p><strong>Cursos disponíveis:</strong> {selectedUniversity.courses.length}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Destaques</h3>
                  <ul className="space-y-1 text-sm">
                    {selectedUniversity.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <span className="text-primary">•</span>
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-muted/50 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground">
            Estima - Guia Universitário para a Periferia de Recife
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Feito com ❤️ para democratizar o acesso ao ensino superior
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
